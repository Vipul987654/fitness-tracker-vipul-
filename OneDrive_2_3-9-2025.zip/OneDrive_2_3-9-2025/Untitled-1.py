try:
    import streamlit as st
    import numpy as np
    import matplotlib.pyplot as plt
    import seaborn as sns
    import pandas as pd
    from sklearn.model_selection import train_test_split
    from sklearn.ensemble import RandomForestRegressor
    import time
    import warnings
    from PIL import Image
    warnings.filterwarnings('ignore')
except ModuleNotFoundError:
    print("Streamlit module not found. Please install it using 'pip install streamlit'.")
    import sys
    sys.exit()

# Page Configuration
st.set_page_config(page_title="🔥 Fitness Tracker", page_icon="🔥", layout="wide", initial_sidebar_state="expanded")

# Background Styling
st.markdown(
    """
    <style>
        body {
            background-color: #f5f7fa;
            color: #333333;
        }
        .sidebar .sidebar-content {
            background-color: #ffcc00 !important;
        }
        .stButton>button {
            background-color: #ff5733 !important;
            color: white !important;
            font-size: 18px !important;
        }
        .stSlider>div>div>div {
            background-color: #4CAF50 !important;
        }
    </style>
    """,
    unsafe_allow_html=True
)

st.title("🌟 Personal Fitness Tracker")
st.write("## Predict Your Calories Burned in Style!")

# Sidebar input for user parameters
st.sidebar.header("🛠️ Customize Your Input")

def user_input_features():
    age = st.sidebar.slider("Age", 10, 100, 30)
    bmi = st.sidebar.slider("BMI", 15, 40, 20)
    duration = st.sidebar.slider("Workout Duration (min)", 0, 60, 15)
    heart_rate = st.sidebar.slider("Heart Rate", 60, 180, 80)
    body_temp = st.sidebar.slider("Body Temperature (°C)", 36, 42, 38)
    gender = st.sidebar.radio("Gender", ["Male", "Female"], index=0)
    
    gender_encoded = 1 if gender == "Male" else 0
    
    return pd.DataFrame({
        "Age": [age],
        "BMI": [bmi],
        "Duration": [duration],
        "Heart_Rate": [heart_rate],
        "Body_Temp": [body_temp],
        "Gender_male": [gender_encoded]
    })

df = user_input_features()
st.write("### 🎯 Your Input Parameters")
st.dataframe(df, use_container_width=True)

# Load and preprocess data
@st.cache_data
def load_data():
    try:
        calories = pd.read_csv(r"C:\\Users\\acer\\Downloads\\OneDrive_2_3-9-2025\\calories.csv")
        exercise = pd.read_csv(r"C:\\Users\\acer\\Downloads\\OneDrive_2_3-9-2025\\exercise.csv")
    except FileNotFoundError:
        st.error("🚨 CSV files not found. Please ensure 'calories.csv' and 'exercise.csv' exist in the directory.")
        st.stop()
    
    exercise_df = exercise.merge(calories, on="User_ID").drop(columns=["User_ID"])
    exercise_df["BMI"] = round(exercise_df["Weight"] / ((exercise_df["Height"] / 100) ** 2), 2)
    exercise_df.dropna(inplace=True)
    
    return exercise_df

exercise_df = load_data()

if exercise_df.empty:
    st.stop()

# Prepare the training and testing sets
exercise_train_data, exercise_test_data = train_test_split(exercise_df, test_size=0.2, random_state=1)
exercise_train_data = pd.get_dummies(exercise_train_data, drop_first=True)
exercise_test_data = pd.get_dummies(exercise_test_data, drop_first=True)

X_train = exercise_train_data.drop("Calories", axis=1)
y_train = exercise_train_data["Calories"]
X_test = exercise_test_data.drop("Calories", axis=1)
y_test = exercise_test_data["Calories"]

# Train the model
random_reg = RandomForestRegressor(n_estimators=500, max_depth=6, random_state=1)
random_reg.fit(X_train, y_train)

df = df.reindex(columns=X_train.columns, fill_value=0)
prediction = random_reg.predict(df)

st.write("### 🔥 Predicted Calories Burned: ")
st.subheader(f"{round(prediction[0], 2)} kilocalories")

# Display similar results
calorie_range = [prediction[0] - 10, prediction[0] + 10]
similar_data = exercise_df[(exercise_df["Calories"] >= calorie_range[0]) & (exercise_df["Calories"] <= calorie_range[1])]

st.write("### 📌 Similar Workout Results")
st.dataframe(similar_data.sample(5) if not similar_data.empty else "No similar results found.")

# Visualization
st.write("### 📊 Data Distribution")
fig, ax = plt.subplots()
sns.histplot(exercise_df["Calories"], bins=30, kde=True, ax=ax, color='purple')
ax.axvline(prediction[0], color='red', linestyle='dashed', label='Your Prediction')
ax.set_xlabel("Calories Burned")
ax.legend()
st.pyplot(fig)

st.write("---")
st.write("### 📢 General Insights")
st.write(f"You're older than **{round((exercise_df['Age'] < df['Age'].values[0]).mean() * 100, 2)}%** of users.")
st.write(f"Your exercise duration is longer than **{round((exercise_df['Duration'] < df['Duration'].values[0]).mean() * 100, 2)}%** of users.")
st.write(f"Your heart rate is higher than **{round((exercise_df['Heart_Rate'] < df['Heart_Rate'].values[0]).mean() * 100, 2)}%** of users.")
st.write(f"Your body temperature is higher than **{round((exercise_df['Body_Temp'] < df['Body_Temp'].values[0]).mean() * 100, 2)}%** of users.")
